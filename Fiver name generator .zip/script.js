const generateBtn = document.getElementById("generateBtn");
const loadingBar = document.getElementById("loadingBar");
const generatedName = document.getElementById("generatedName");
const toggle = document.getElementById("toggle");

const fileMap = {
  female: "female names.txt",
  male: "male names.txt",
  bot: "Bot names.txt",
  combined: "combined names.txt",
};

function fetchNames(file) {
  return fetch(file)
    .then((response) => response.text())
    .then((text) => text.split("\n").map((name) => name.trim()))
    .catch((error) => {
      console.error(`Error loading file: ${file}`, error);
      return [];
    });
}

generateBtn.addEventListener("click", async () => {
  const gender = document.getElementById("gender").value;

  // Random chance to pick from combined names (e.g., 25%)
  const pickCombined = Math.random() < 0.25;

  let genderNames, botNames;
  if (pickCombined) {
    // Pick randomly from the combined names if chosen
    const combinedNames = await fetchNames(fileMap.combined);
    const selectedName = getRandomItem(combinedNames);
    showLoadingBar(() => {
      generatedName.textContent = `Generated Name: ${selectedName}`;
    });
    return;
  } else {
    // Otherwise, pick from gender-specific names + bot names
    const [genderFile, botFile] = gender === "female" ?
      [fileMap.female, fileMap.bot] :
      [fileMap.male, fileMap.bot];

        [genderNames, botNames] = await Promise.all([fetchNames(genderFile), fetchNames(botFile)]);

    const selectedName = `${getRandomItem(genderNames)} ${getRandomItem(botNames)}`;

    showLoadingBar(() => {
      generatedName.textContent = `Generated Name: ${selectedName}`;
    });
  }
});

function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function showLoadingBar(callback) {
  loadingBar.classList.remove("hidden");
  setTimeout(() => {
    loadingBar.classList.add("hidden");
    callback();
  }, Math.random() * 4000 + 1000); // Random duration between 1-5 seconds
}

// Dark Mode Toggle
toggle.addEventListener("change", () => {
  document.body.classList.toggle("dark");
});

// Function to generate a random dark color
function getRandomDarkColor() {
    // Generate random RGB values in a dark range
    const r = Math.floor(Math.random() * 100); // Red between 0-100
    const g = Math.floor(Math.random() * 100); // Green between 0-100
    const b = Math.floor(Math.random() * 100); // Blue between 0-100
    return `rgb(${r}, ${g}, ${b})`;
}

// Set a random dark background color when the page loads
document.body.style.backgroundColor = getRandomDarkColor();